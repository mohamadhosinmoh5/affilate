  
function setDate(){
    var dateFields = document.getElementsByClassName('dateFa');
    
    for (let index = 0; index < dateFields.length; index++) {
        const element = dateFields[index];
        console.log(element);
        element.pDatepicker({
            initialValueType: "persian",
            format: "YYYY/MM/DD",
            onSelect: "year",
            persianDigit:true,
            calendar:{
                persian:{
                    locale:'en'
                }
            }
        });
    }

}
setDate();